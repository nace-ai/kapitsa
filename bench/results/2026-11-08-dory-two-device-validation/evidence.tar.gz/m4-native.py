import fcntl,json,os,pathlib,signal,subprocess,sys,time
R=pathlib.Path(__file__).resolve().parent;E=R/'m4-native-evidence';E.mkdir(exist_ok=False);T=pathlib.Path('/Users/bytedance/.codex/worktrees/dory-shared-reduction/qwen-nameless-tool');sys.path.insert(0,str(T/'bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':time.time(),'status':'waiting model checks','runs':[]}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
save()
try:
 while True:
  prior=json.loads((R/'m4-evidence/state.json').read_text())
  if prior['status']=='failed':raise RuntimeError(prior.get('error'))
  if prior['status'].startswith('complete'):break
  time.sleep(10)
 assert all(prior['equal_ids'].values()) and all(x['valid'] for x in prior['continuations'])
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX)
  for i,a in enumerate(['reference','dory','reference','dory']):
   name=f'bench-{i}-{a}';home=E/'homes'/name;home.mkdir(parents=True);env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1',KAPITSA_HOME=str(home))
   cmd=[str(R/'m4-tools'/(a+'_kapitsa')),'bench','--model','/Volumes/KapitsaDoryReady/nemotron-labs-dory1.0-4b-nvfp4','--quick','--json','--out',str(E/(name+'.json'))];row={'name':name,'command':cmd,'start':time.time()};S['runs'].append(row);S['status']=name;save()
   row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save();assert row['quiet'][0]
   mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
   try:
    with (E/(name+'.log')).open('x') as f:
     p=subprocess.Popen(cmd,cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
     try:row['rc']=p.wait(timeout=1800)
     except subprocess.TimeoutExpired:
      row['timeout']=1800;os.killpg(p.pid,signal.SIGTERM)
      try:p.wait(timeout=20)
      except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
      row['rc']=p.returncode
   finally:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples);row['end']=time.time();save()
 S['status']='complete; inspect every native result';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
