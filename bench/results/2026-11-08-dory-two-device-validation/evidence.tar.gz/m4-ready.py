import datetime,fcntl,hashlib,json,os,pathlib,plistlib,re,signal,subprocess,sys,tarfile,time
R=pathlib.Path(__file__).resolve().parent;E=R/'m4-evidence';E.mkdir(exist_ok=False);B=R/'m4-tools';T=pathlib.Path('/Users/bytedance/.codex/worktrees/dory-shared-reduction/qwen-nameless-tool');M=pathlib.Path('/Volumes/KapitsaDoryReady/nemotron-labs-dory1.0-4b-nvfp4')
sys.path.insert(0,str(T/'bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'waiting model and tools','source':'b3bece8931c78885e682bfb8da771598d721093a','reference':'bbd84e0d53be75866087aa615bdeb6f2411f393f'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def run(name,cmd,gpu=True,extra=None,required=True,timeout=3600):
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1');env.update(extra or {})
 row={'name':name,'command':list(map(str,cmd)),'extra_env':extra or {},'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:raise RuntimeError('GPU contention before '+name)
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row['timeout']=timeout;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 if required:assert row.get('rc')==0,row
 return row.get('rc')==0
save()
try:
 while True:
  s=json.loads((R/'m4-download-state.json').read_text())
  if s['status']=='failed':raise RuntimeError(s)
  if s['status'].startswith('complete') and (B/'dory_reduce_check').exists():break
  time.sleep(10)
 vol=plistlib.loads(subprocess.check_output(['/usr/sbin/diskutil','info','-plist',M.parent]));expected=plistlib.loads((R/'m4-volume.plist').read_bytes());assert vol['VolumeUUID']==expected['VolumeUUID'];S['volume']=vol['VolumeUUID']
 S['weights_sha256']=sha(M/'model.safetensors');assert S['weights_sha256']=='ca08dec5d70b653c03e57903dd33725ec8cc80133c53a1bd9c83f99dd03f3e46'
 S['binaries']={p.name:sha(p) for p in B.iterdir() if p.is_file() and os.access(p,os.X_OK)};save()
 old=R.parent/'followup-20261107T162024/verified-remote/model-checks/prompt-clean.ids';assert old.exists();ids=list(map(int,old.read_text().strip().split(',')))
 for n in [len(ids),16384]:
  p=E/f'prompt-{n}.ids';p.write_text(','.join(map(str,(ids*((n+len(ids)-1)//len(ids)))[:n]))+'\n')
 seed=E/'long-seed';seed.mkdir();seq=(ids*((16384+25+len(ids)-1)//len(ids)))[:16384+25];(seed/'sequences.txt').write_text(' '.join(map(str,seq))+'\n');(seed/'records.txt').write_text(''.join(f'0 {16384+j+1}\n' for j in range(24)))
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX)
  run('small-debug',[B/'dory_reduce_check','--gpu','--small'],extra={'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1'})
  run('all-gpu',[B/'dory_reduce_check','--gpu']);run('kernel-bench',[B/'dory_reduce_check','--bench'])
  for mode in ['ordinary','long']:
   paths=[]
   for arm in ['reference','dory']:
    dest=M.parent/(mode+'-'+arm+'-logits');paths.append(dest)
    cmd=[B/(arm+'_logit_dump'),M,dest,'--paths','step,verify','--loop-kv','per-loop']
    if arm=='dory':cmd+=['--from',paths[0]]
    elif mode=='long':cmd+=['--from',seed]
    else:cmd+=['--corpus',T/'bench/corpus.txt']
    run(mode+'-logits-'+arm,cmd)
   run(mode+'-compare',[sys.executable,T/'tools/logit_compare.py',*paths,'--json',E/(mode+'-compare.json')],gpu=False,required=False)
   for dest in paths:
    for p in dest.rglob('*'):
     if p.is_file():
      S.setdefault('dump_hashes',{})[str(p.relative_to(M.parent))]=sha(p)
      if p.suffix!='.f32':
       q=E/'metadata'/dest.name/p.relative_to(dest);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    import shutil;shutil.rmtree(dest)
   save()
  eos=json.loads((M/'generation_config.json').read_text())['eos_token_id'];eos=set(eos if isinstance(eos,list) else [eos]);S['continuations']=[]
  for n in [len(ids),16384]:
   outputs=[]
   for i,arm in enumerate(['reference','dory','reference','dory']):
    name=f'decode-{n}-{i}-{arm}';run(name,[B/(arm+'_run'),M,'@'+str(E/f'prompt-{n}.ids'),'256'])
    text=(E/(name+'.log')).read_text();out=list(map(int,re.search(r'^ids:(.*)$',text,re.M).group(1).split()));f=E/(name+'.ids');f.write_text(' '.join(map(str,out)))
    dec=subprocess.run([B/'token_helper',M/'tokenizer.json','decode',f],capture_output=True,text=True);(E/(name+'.text')).write_text(dec.stdout);row={'name':name,'count':len(out),'end_tokens':sum(x in eos for x in out),'nonempty':bool(dec.stdout.strip()),'decode_rc':dec.returncode,'timing':re.findall(r'prompt .*',text)};row['valid']=row['count']==256 and row['end_tokens']==0 and row['nonempty'] and not dec.returncode;S['continuations'].append(row);outputs.append(out);save()
   S.setdefault('equal_ids',{})[str(n)]=all(x==outputs[0] for x in outputs);save()
 S['status']='complete; analyze gates, controls and validity';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
