import datetime,fcntl,hashlib,json,os,pathlib,re,signal,socket,subprocess,sys,time,urllib.request
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');E=R/'dory-fixed-ready-20261108';E.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'bf16/bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'preflight'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def environment(name):
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};p=E/'homes'/name;p.mkdir(parents=True,exist_ok=True)
 env.update(PATH='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1',KAPITSA_HOME=str(p));return env
def run(name,cmd,cwd=None,gpu=True,timeout=3600):
 row={'name':name,'command':list(map(str,cmd)),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:row['skipped']='GPU busy';save();return False
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=cwd or R/'reference',env=environment(name),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row['timeout']=timeout;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 return row.get('rc')==0
def http(arm,model,tag,flags):
 name=tag+'-'+arm
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 cmd=[str(R/arm/'build/kapitsa'),'serve','--model',str(model),'--private','--host','127.0.0.1','--port',str(port),'--ctx','32768','--slots','2','--disk-cache','0',*flags]
 row={'name':name+'-server','command':cmd};S['runs'].append(row);save()
 with (E/(name+'-server.log')).open('x') as f:
  p=subprocess.Popen(cmd,cwd=R/arm,env=environment(name+'-server'),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:
   row['ready']=False
   for _ in range(300):
    if p.poll()!=None:break
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as res:
      if res.status==200:row['ready']=True;break
    except Exception:pass
    time.sleep(2)
   save()
   if row['ready']:run(name,['python3',R/arm/'tests/test_server.py',f'http://127.0.0.1:{port}'],timeout=1800)
  finally:
   if p.poll()==None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=30)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   row['cleaned_up']=True;row['rc_after_stop']=p.returncode;save()
try:
 prior=json.loads((R/'ready-push-20261108/state.json').read_text());S['source_heads']=prior['heads'];S['driver_sha256']={a:sha(R/'model-checks/build'/(a+'_run')) for a in ['reference','dory']};save()
 ids=list(map(int,(R/'model-checks/prompt-clean.ids').read_text().strip().split(',')));model=pathlib.Path('/Volumes/KapitsaDoryProbe/nemotron-labs-dory1.0-4b-nvfp4');assert sha(model/'model.safetensors')=='ca08dec5d70b653c03e57903dd33725ec8cc80133c53a1bd9c83f99dd03f3e46'
 eos=json.loads((model/'generation_config.json').read_text())['eos_token_id'];eos=set(eos if isinstance(eos,list) else [eos]);S['continuations']=[]
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX)
  for n in [8192,16384]:
   prompt=E/f'prompt-{n}.ids';prompt.write_text(','.join(map(str,(ids*((n+len(ids)-1)//len(ids)))[:n]))+'\n');outputs=[]
   for i,a in enumerate(['reference','dory','reference','dory']):
    name=f'decode-{n}-{i}-{a}';assert run(name,[R/'model-checks/build'/(a+'_run'),model,'@'+str(prompt),'256'])
    text=(E/(name+'.log')).read_text();out=list(map(int,re.search(r'^ids:(.*)$',text,re.M).group(1).split()));f=E/(name+'.ids');f.write_text(' '.join(map(str,out)));dec=subprocess.run([R/'model-checks/build/token_helper',model/'tokenizer.json','decode',f],capture_output=True,text=True);(E/(name+'.text')).write_text(dec.stdout)
    row={'name':name,'count':len(out),'end_tokens':sum(x in eos for x in out),'nonempty':bool(dec.stdout.strip()),'decode_rc':dec.returncode,'timing':re.findall(r'prompt .*',text)};row['valid']=row['count']==256 and row['end_tokens']==0 and row['nonempty'] and not dec.returncode;S['continuations'].append(row);outputs.append(out);save()
   S.setdefault('equal_ids',{})[str(n)]=all(x==outputs[0] for x in outputs);save()
 S['status']='complete; analyze long context timing and output validity';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
