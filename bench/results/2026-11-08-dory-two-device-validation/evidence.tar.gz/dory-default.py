import fcntl,hashlib,json,os,pathlib,signal,subprocess,sys,time
remote=sys.argv[1]=='m3'
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107') if remote else pathlib.Path(__file__).resolve().parent
E=R/'dory-default-ready';E.mkdir(exist_ok=False)
T=R/'dory' if remote else pathlib.Path('/Users/bytedance/.codex/worktrees/dory-shared-reduction/qwen-nameless-tool')
M=pathlib.Path('/Volumes/KapitsaDoryProbe' if remote else '/Volumes/KapitsaDoryReady')/'nemotron-labs-dory1.0-4b-nvfp4'
prior=R/('dory-fixed-ready-20261108' if remote else 'm4-native-evidence')/'state.json'
B={a:R/a/'build/logit_dump' if remote else R/'m4-tools'/(a+'_logit_dump') for a in ['reference','dory']}
sys.path.insert(0,str(T/'bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':time.time(),'status':'waiting preceding tests','runs':[],'model':str(M),'mode':'last-loop default'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def run(name,cmd,gpu=True):
 row={'name':name,'command':list(map(str,cmd)),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1')
 if remote:env['PATH']='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save();assert row['quiet'][0];mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['timeout']=1800;row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 assert row.get('rc')==0,row
save()
try:
 while True:
  s=json.loads(prior.read_text())
  if s['status']=='failed':raise RuntimeError(s.get('error'))
  if s['status'].startswith('complete'):break
  time.sleep(10)
 S['binary_sha256']={a:sha(b) for a,b in B.items()};save()
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX);outs=[]
  for a,b in B.items():
   d=E/(a+'-logits');outs.append(d);cmd=[b,M,d,'--paths','step','--loop-kv','last-loop','--corpus',T/'bench/corpus.txt']
   if a=='dory':cmd+=['--from',outs[0]]
   run(a+'-default-logits',cmd)
  run('default-compare',['python3' if remote else sys.executable,T/'tools/logit_compare.py',*outs,'--json',E/'default-compare.json'],gpu=False)
  for d in outs:
   for p in d.rglob('*.f32'):S.setdefault('raw_sha256',{})[str(p.relative_to(E))]=sha(p);p.unlink()
 S['status']='complete; default last-loop output gate passed';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
