# Privacy-filtered derived export. Private environment identifiers and host resource records are omitted; measurements, outcomes and tested source/binary identities are retained. Modified commands are placeholder reproduction examples, not verbatim execution logs. Original bytes remain privately archived.
import datetime,fcntl,hashlib,json,os,pathlib,signal,subprocess,sys,time
R=pathlib.Path('$PRIVATE_PATH');E=R/'router-output-supported-paths';E.mkdir(exist_ok=False);T={'reference':R/'router-reference','router':R/'router'};H={'reference':'f22effb9bdda7fa17be5e4ce614383a35e1cc62a','router':'dc82cf0f39b942157e86b0cd5e518e5caed17e61'}
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'heads':H,'status':'waiting prior controlled job'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def env(name):
 e={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};p=E/'homes'/name;p.mkdir(parents=True,exist_ok=True);e.update(PATH='$PRIVATE_PATH',KAPITSA_HOME=str(p),KAPITSA_NO_AUTO_UPDATE='1',NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1');return e
def run(name,cmd,tree,gpu=False,required=True):
 row={'name':name,'command':list(map(str,cmd)),'cwd':str(tree),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:raise RuntimeError('GPU not quiet')
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=tree,env=env(name),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=3600)
   except subprocess.TimeoutExpired:
    row['timeout']=3600;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 if required:assert row.get('rc')==0,row
 return row.get('rc')==0
save()
try:
 prior=json.loads((R/'router-ready-20261108/state.json').read_text())
 table=json.loads((R/'flash-complete-ready/parallel-state.json').read_text())
 assert table['status'].startswith('complete;') and table['sha256']==table['expected_sha256']
 S['resumes_failed_job']=str(R/'router-ready-20261108/state.json')
 S['fix']='Flash-Next does not implement batch decode; supported step/verify with prefill output only. Original failure preserved.'
 for a,t in T.items():
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip()==H[a]
 S['binary_sha256']={a+'/'+b:sha(t/'build'/b) for a,t in T.items() for b in ['kapitsa','logit_dump','ni_run']}
 assert S['binary_sha256']==prior['binary_sha256']
 sys.path.insert(0,str(T['router']/'bench/harness'));import gpu_hogs
 p=pathlib.Path(table['model']);S['model']=str(p);S['table_sha256']=table['sha256'];save()
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU for Flash-Next';save();fcntl.flock(lock,fcntl.LOCK_EX)
  outputs=[]
  for a,t in T.items():
   d=E/('flash-'+a+'-logits');outputs.append(d);cmd=[t/'build/logit_dump',p,d,'--paths','step,verify','--corpus',t/'bench/corpus.txt']
   if a=='router':cmd+=['--from',outputs[0]]
   run('flash-logits-'+a,cmd,t,gpu=True)
  run('flash-compare',['python3',T['router']/'tools/logit_compare.py',*outputs,'--json',E/'flash-compare.json'],T['router'],required=False)
  for d in outputs:
   for f in d.rglob('*.f32'):S.setdefault('raw_sha256',{})[str(f.relative_to(E))]=sha(f);f.unlink()
  save()
 S['status']='complete; inspect all outputs; model performance and HTTP follow-up next';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
