import datetime,fcntl,hashlib,json,os,pathlib,re,signal,socket,subprocess,sys,time,urllib.request
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');E=R/'router-model-followup-supported-paths';E.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'bf16/bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'preflight'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def environment(name):
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};p=E/'homes'/name;p.mkdir(parents=True,exist_ok=True)
 env.update(PATH='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1',KAPITSA_HOME=str(p));return env
def run(name,cmd,cwd=None,gpu=True,timeout=3600):
 row={'name':name,'command':list(map(str,cmd)),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:row['skipped']='GPU busy';save();return False
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=cwd or R/'reference',env=environment(name),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row['timeout']=timeout;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 return row.get('rc')==0
def http(arm,model,tag,flags):
 name=tag+'-'+arm
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 cmd=[str(R/arm/'build/kapitsa'),'serve','--model',str(model),'--private','--host','127.0.0.1','--port',str(port),'--ctx','32768','--slots','2','--disk-cache','0',*flags]
 row={'name':name+'-server','command':cmd};S['runs'].append(row);save()
 with (E/(name+'-server.log')).open('x') as f:
  p=subprocess.Popen(cmd,cwd=R/arm,env=environment(name+'-server'),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:
   row['ready']=False
   for _ in range(300):
    if p.poll()!=None:break
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as res:
      if res.status==200:row['ready']=True;break
    except Exception:pass
    time.sleep(2)
   save()
   if row['ready']:run(name,['python3',R/arm/'tests/test_server.py',f'http://127.0.0.1:{port}'],timeout=1800)
  finally:
   if p.poll()==None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=30)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   row['cleaned_up']=True;row['rc_after_stop']=p.returncode;save()
try:
 prior=R/'router-output-supported-paths/state.json'
 while True:
  try:state=json.loads(prior.read_text())
  except (ValueError,FileNotFoundError):time.sleep(2);continue
  if state['status']=='failed':raise RuntimeError(state.get('error'))
  if state['status'].startswith('complete; inspect all outputs'):break
  S['status']='waiting complete router model-output job';save();time.sleep(15)
 assert all(x.get('rc')==0 for x in state['runs'] if x['name']=='flash-compare'),state['runs']
 report=json.loads((R/'router-output-supported-paths/flash-compare.json').read_text());assert all(not x['failures'] and not x['non_finite'] for x in report['paths'].values())
 model=pathlib.Path(state['model']);S['model']=str(model);S['source_heads']=state['heads'];S['binary_sha256']=state['binary_sha256'];save()
 for a,h in [('router-reference',state['heads']['reference']),('router',state['heads']['router'])]:assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R/a,text=True).strip()==h
 prompt=pathlib.Path('/Users/bytedance/kapitsa-ngram-remote-20261107/evidence/chat-prompt.ids');assert prompt.exists();(E/'prompt.ids').write_bytes(prompt.read_bytes());S['prompt_sha256']=sha(E/'prompt.ids');S['continuations']=[];save()
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX);outputs=[]
  for i,a in enumerate(['router-reference','router','router-reference','router']):
   name=f'fixed-{i}-{a}';ok=run(name,[R/a/'build/ni_run',model,'@'+str(E/'prompt.ids'),'256','0','--dflash','none','--spec','0']);assert ok
   text=(E/(name+'.log')).read_text();ids=list(map(int,re.search(r'^ids:(.*)$',text,re.M).group(1).split()));p=E/(name+'.ids');p.write_text(' '.join(map(str,ids)));d=subprocess.run([R/'model-checks/build/token_helper',model/'tokenizer.json','decode',p],capture_output=True,text=True);(E/(name+'.text')).write_text(d.stdout);row={'name':name,'count':len(ids),'nonempty':bool(d.stdout.strip()),'end_tokens':sum(x in [248044,248046] for x in ids),'timing':re.findall(r'prompt .*',text)};S['continuations'].append(row);outputs.append(ids);save();assert row['count']==256 and row['nonempty'] and row['end_tokens']==0 and d.returncode==0,row
  S['equal_ids']=all(x==outputs[0] for x in outputs);save();assert S['equal_ids']
  http('router',model,'flash-default-http',[])
  tests=[x for x in S['runs'] if x['name']=='flash-default-http-router'];assert tests
  if tests[-1].get('rc')!=0:http('router-reference',model,'flash-default-http',[])
  for i,a in enumerate(['router-reference','router','router-reference','router']):
   name=f'flash-native-{i}-{a}';run(name,[R/a/'build/kapitsa','bench','--model',model,'--quick','--json','--out',E/(name+'.json')],timeout=3600)
 S['status']='complete; inspect model output, HTTP baseline differences and all native flags before Ready';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
