# Privacy-filtered derived export. Private environment identifiers and host resource records are omitted; measurements, outcomes and tested source/binary identities are retained. Modified commands are placeholder reproduction examples, not verbatim execution logs. Original bytes remain privately archived.
from pathlib import Path
import subprocess
r=Path('$PRIVATE_PATH')
original=(r/'router-ready.py').read_text();prefix=original[:original.index('save()\ntry:')]
prefix=prefix.replace("E=R/'router-ready-20261108'","E=R/'router-output-supported-paths'")
body=original[original.index(" p=pathlib.Path(table['model'])"):]
body=body.replace("cmd=[t/'build/logit_dump',p,d,'--corpus',t/'bench/corpus.txt']","cmd=[t/'build/logit_dump',p,d,'--paths','step,verify','--corpus',t/'bench/corpus.txt']")
body=body[:body.index(' for what,cmd')] + body[body.index(" with open('/tmp/kapitsa-gpu.lock'",body.index(' for what,cmd')):]
setup="""save()
try:
 prior=json.loads((R/'router-ready-20261108/state.json').read_text())
 table=json.loads((R/'flash-complete-ready/parallel-state.json').read_text())
 assert table['status'].startswith('complete;') and table['sha256']==table['expected_sha256']
 S['resumes_failed_job']=str(R/'router-ready-20261108/state.json')
 S['fix']='Flash-Next does not implement batch decode; supported step/verify with prefill output only. Original failure preserved.'
 for a,t in T.items():
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip()==H[a]
 S['binary_sha256']={a+'/'+b:sha(t/'build'/b) for a,t in T.items() for b in ['kapitsa','logit_dump','ni_run']}
 assert S['binary_sha256']==prior['binary_sha256']
 sys.path.insert(0,str(T['router']/'bench/harness'));import gpu_hogs
"""
(r/'router-output-supported-paths.py').write_text(prefix+setup+body)
f=(r/'router-model-followup.py').read_text().replace("E=R/'router-model-followup-ready'","E=R/'router-model-followup-supported-paths'").replace('router-ready-20261108/','router-output-supported-paths/')
(r/'router-model-followup-supported-paths.py').write_text(f)
for script in ['router-output-supported-paths.py','router-model-followup-supported-paths.py']:
 compile((r/script).read_text(),str(r/script),'exec')
 with (r/(script+'.launcher.log')).open('x') as log:
  p=subprocess.Popen(['/usr/bin/python3',str(r/script)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(script,p.pid)
