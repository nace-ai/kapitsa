#!/usr/bin/env bash
set -euo pipefail
export PATH=/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH
export PYTHONUNBUFFERED=1
R=/Users/bytedance/kapitsa-two-candidates-20261107
cd "$R/dory"
export VK_RUN=two-candidates-dory-v2 VK_EVIDENCE="$R/dory-v2-evidence/vk"
mkdir -p "$R/dory-v2-evidence/extra"
trap 'echo $? > "$R/dory-v2.rc"' EXIT
V=.dsh/skills/verify-kapitsa/scripts/vk
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DKAPITSA_GIT=b3bece89 > "$R/dory-v2-evidence/configure.log" 2>&1
$V build kapitsa api_test execution_session_test http_stream_test bench_test update_test prefix_cache_test grammar_test structured_check fn_store_test fn_dflash_test drafter_attach_test tokenizer_test iq_layout_test exl3_test remote_test cluster_test split_place_test gemm_slices_test device_profile_test qwen4_config_test json_file_test affine_pack_test systemone systemone_test systemone_codes_probe_test systemone_codes_driver splash_protocol_test splash_runtime_test splash_discover_test splash_plan_test ws_upgrade_test logit_dump dory_reduce_check
cp "$R/dory-v2-evidence/vk/two-candidates-dory-v2/b3bece89/build.log" "$R/dory-v2-evidence/full-build.log"
$V doctor > "$R/dory-v2-evidence/doctor.log"
$V gpu run --eta 5 --label 'Dory separate pipelines verification' -- python3 "$R/gpu-checks-v2.py"
touch "$R/dory-v2.gpu.done"
$V cpu-tests
for target in execution_session_test http_stream_test drafter_attach_test exl3_test device_profile_test qwen4_config_test json_file_test affine_pack_test systemone_test systemone_codes_probe_test splash_protocol_test splash_runtime_test splash_discover_test splash_plan_test; do
  build/$target > "$R/dory-v2-evidence/extra/$target.log" 2>&1
  echo "PASS extra $target"
done
for script in tests/test_profile_gates.py tests/test_comment_gates.py tests/test_drex_max.py tests/test_logit_dump.py tools/qwen4_exp_pack_test.py; do
  name=$(basename "$script" .py)
  case "$name" in
    test_drex_max) python3 "$script" --cli build > "$R/dory-v2-evidence/extra/$name.log" 2>&1 ;;
    test_logit_dump) python3 "$script" build > "$R/dory-v2-evidence/extra/$name.log" 2>&1 ;;
    *) python3 "$script" > "$R/dory-v2-evidence/extra/$name.log" 2>&1 ;;
  esac
  echo "PASS extra $name"
done
$V checks bbd84e0d53be75866087aa615bdeb6f2411f393f
$V cleanup
touch "$R/dory-v2.final.done"
