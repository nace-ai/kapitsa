import datetime,json,os,pathlib,subprocess,sys
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107')
sys.path.insert(0,str(R/'dory/bench/harness'))
import gpu_hogs
E=R/'dory-v2-evidence'
s={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'source':'b3bece8931c78885e682bfb8da771598d721093a','runs':[]}
for name,args,debug in [('gpu-small',['--gpu','--small'],True),('gpu-full',['--gpu'],False),('gpu-bench',['--bench'],False)]:
 q=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid(),os.getppid()])
 row={'name':name,'quiet':q,'args':args};s['runs'].append(row)
 (E/'gpu-state.json').write_text(json.dumps(s,indent=2)+'\n')
 assert q[0],q
 env=dict(os.environ,NI_LOCK_HELD='1')
 if debug:env.update(MTL_SHADER_VALIDATION='1',MTL_DEBUG_LAYER='1')
 m=gpu_hogs.ContentionMonitor([os.getpid(),os.getppid()],interval=.5);m.start()
 try:
  with (E/(name+'.log')).open('w') as f:row['rc']=subprocess.run([str(R/'dory/build/dory_reduce_check')]+args,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 finally:
  m.stop();row['contention']=gpu_hogs.summarize_samples(m.samples);row['samples']=m.samples
  (E/'gpu-state.json').write_text(json.dumps(s,indent=2)+'\n')
 assert row['rc']==0,row
s['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(E/'gpu-state.json').write_text(json.dumps(s,indent=2)+'\n')
