#include "tokenizer/tokenizer.h"
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
int main(int argc,char** argv) {
 if(argc!=4)return 2;
 ni::Tokenizer t;t.load(argv[1]);
 std::ifstream in(argv[3]);std::string s((std::istreambuf_iterator<char>(in)),{});
 if(std::string(argv[2])=="encode") {auto ids=t.encode(s);for(size_t i=0;i<ids.size();++i)std::cout<<(i?",":"")<<ids[i];std::cout<<"\n";}
 else {std::stringstream ss(s);std::vector<int> ids;int n;while(ss>>n)ids.push_back(n);std::cout<<t.decode(ids);}
}
