import datetime,fcntl,hashlib,json,os,pathlib,plistlib,re,shutil,subprocess,sys,time
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107')
E=R/'model-checks'
sys.path.insert(0,str(R/'dory/bench/harness'))
import gpu_hogs
s={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'waiting for reference build'}
def save(): (E/'state.json').write_text(json.dumps(s,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def run(name,cmd,gpu=False):
 row={'name':name,'command':list(map(str,cmd))};s['runs'].append(row);s['status']=name;save()
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_'))};env['NI_LOCK_HELD']='1';env['KAPITSA_NO_AUTO_UPDATE']='1'
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save();assert row['quiet'][0]
  m=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);m.start()
 try:
  with (E/(name+'.log')).open('w') as f:row['rc']=subprocess.run(row['command'],env=env,stdout=f,stderr=subprocess.STDOUT,cwd=R/'reference').returncode
 finally:
  if gpu:m.stop();row['contention']=gpu_hogs.summarize_samples(m.samples);row['samples']=m.samples
  save()
 assert row['rc']==0,(name,row['rc'])
save()
try:
 while not (R/'reference.rc').exists():time.sleep(10)
 for name in ['dory-v2.rc','bf16.rc','reference.rc']:assert (R/name).read_text().strip()=='0',name
 s['source_heads']={k:subprocess.check_output(['git','-C',str(R/k),'rev-parse','HEAD'],text=True).strip() for k in ['dory','bf16','reference']}
 assert s['source_heads']=={'dory':'b3bece8931c78885e682bfb8da771598d721093a','bf16':'5e174cb89eb991a705752d033f7f9da8edfeff87','reference':'bbd84e0d53be75866087aa615bdeb6f2411f393f'}
 info=plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/KapitsaDoryProbe']))
 assert info['VolumeUUID']=='AED344A9-91D2-3F54-AFB5-E8D55E3871E4'
 vol=pathlib.Path('/Volumes/KapitsaDoryProbe');dory=vol/'nemotron-labs-dory1.0-4b-nvfp4';s['model_weights_sha256']=sha(dory/'model.safetensors');assert s['model_weights_sha256']=='ca08dec5d70b653c03e57903dd33725ec8cc80133c53a1bd9c83f99dd03f3e46'
 run('drivers-configure',['/opt/homebrew/bin/cmake','-S',E,'-B',E/'build','-DCMAKE_BUILD_TYPE=Release'])
 run('drivers-build',['/opt/homebrew/bin/cmake','--build',E/'build','-j','4'])
 s['binary_sha256']={f'{k}/{b}':sha(R/k/'build'/b) for k in ['reference','dory','bf16'] for b in ['kapitsa','logit_dump']};save()
 dumps=vol/'two-candidate-source-logits';assert not dumps.exists();dumps.mkdir()
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  s['status']='waiting for GPU';save();fcntl.flock(lock,fcntl.LOCK_EX)
  for kind,model,paths,extras in [('dory',dory,'step,verify',['--loop-kv','per-loop']),('bf16',pathlib.Path('/Users/bytedance/pr934-m3-validation-20261105/modelhome/models/qwen3.5-4b-4bit'),'step,verify,batch',[])]:
   for arm in ['reference',kind]:
    dest=dumps/(kind+'-'+arm);cmd=[R/arm/'build/logit_dump',model,dest,'--paths',paths,'--corpus',R/'reference/bench/corpus.txt']+extras
    if arm!= 'reference':cmd+=['--from',dumps/(kind+'-reference')]
    run(kind+'-logits-'+arm,cmd,True)
   run(kind+'-logit-compare',['python3',R/'reference/tools/logit_compare.py',dumps/(kind+'-reference'),dumps/(kind+'-'+kind)])
   for arm in ['reference',kind]:
    dest=dumps/(kind+'-'+arm)
    for f in dest.rglob('meta.json'):(E/(kind+'-'+arm+'-'+f.parent.name+'-meta.json')).write_bytes(f.read_bytes())
    s[kind+'-'+arm+'-raw_sha256']={str(f.relative_to(dest)):sha(f) for f in dest.rglob('*') if f.is_file()}
    shutil.rmtree(dest)
   save()
  eos=json.loads((dory/'generation_config.json').read_text())['eos_token_id'];eos=set(eos if isinstance(eos,list) else [eos]);outputs=[];s['continuations']=[]
  for i,arm in enumerate(['reference','dory','reference','dory']):
   name=f'dory-decode-{i}-{arm}';run(name,[E/'build'/(arm+'_run'),dory,'@'+str(E/'prompt-clean.ids'),'256'],True)
   text=(E/(name+'.log')).read_text();ids=list(map(int,re.search(r'^ids:(.*)$',text,re.M).group(1).split()));f=E/(name+'.ids');f.write_text(' '.join(map(str,ids)))
   out=subprocess.run([str(E/'build/token_helper'),str(dory/'tokenizer.json'),'decode',str(f)],capture_output=True,text=True);assert out.returncode==0
   (E/(name+'.text')).write_text(out.stdout);(E/(name+'-tokenizer.log')).write_text(out.stderr)
   row={'name':name,'count':len(ids),'nonempty':bool(out.stdout.strip()),'end_tokens':sum(x in eos for x in ids),'ids_sha256':sha(f),'timing':re.findall(r'prompt .*',text)};s['continuations'].append(row);save();assert row['count']==256 and row['nonempty'] and row['end_tokens']==0
   outputs.append(ids)
  s['continuation_ids_equal']=all(x==outputs[0] for x in outputs);assert s['continuation_ids_equal']
 dumps.rmdir();s['status']='complete';s['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 s['status']='failed';s['error']=repr(e);save();raise
