// Plain Dory generation through the production Model interface; no drafter.
#include "bench/bench.h"
#include "engine/engine.h"
#include "metal/gpu.h"
#include "model/dory.h"
#include "util/log.h"
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iterator>
#include <sstream>
#include <vector>
using namespace ni;
int main(int argc, char** argv) {
  if (argc < 4) fatal("usage: dory_run MODEL @IDS N");
  bench::GpuLock lock;
  if (!bench::GpuLock::held_by_caller() && !lock.acquire()) fatal("GPU lock busy");
  std::string path = argv[2];
  if (path.empty() || path[0] != '@') fatal("prompt must be an @file");
  std::ifstream f(path.substr(1));
  std::string text((std::istreambuf_iterator<char>(f)), {}), word;
  std::stringstream ss(text);
  std::vector<int> ids;
  while (std::getline(ss, word, ',')) ids.push_back(std::stoi(word));
  const int count = std::stoi(argv[3]), n = int(ids.size());
  if (n < 1 || count < 1) fatal("empty prompt or generation");
  Dory m(argv[1], 2048, 0, LoopKv::per_loop);
  Gpu& gpu = Gpu::get();
  auto seq = m.new_seq(std::max(8192, n + count + 64));
  std::copy(ids.begin(), ids.end(), seq->tokens());
  SamplingParams sp;
  sp.temperature = 0;
  double start = now_ms();
  for (int pos = 0; pos < n;) {
    const int rows = prefill_chunk_rows(m.prefill_chunk(), pos, n, prefill_even_chunks());
    auto e = gpu.begin();
    m.encode_prefill(*e, *seq, pos, rows, sp, 0, pos + rows == n);
    e->commit_and_wait();
    pos += rows;
  }
  const double prefill_ms = now_ms() - start;
  std::vector<int> out{seq->tokens()[n]};
  start = now_ms();
  double gpu_ms = 0;
  for (int step = 1; step < count; ++step) {
    auto e = gpu.begin();
    m.encode_step(*e, *seq, n + step - 1, sp, unsigned(step), true);
    e->commit_and_wait();
    gpu_ms += e->gpu_ms();
    out.push_back(seq->tokens()[n + step]);
    if (std::find(m.eos_ids().begin(), m.eos_ids().end(), out.back()) != m.eos_ids().end()) break;
  }
  const double decode_ms = now_ms() - start;
  printf("ids:");
  for (int id : out) printf(" %d", id);
  printf("\n");
  fprintf(stderr, "Dory loops=%d KV=%s drafter=none synchronous Model::encode_step\n", m.default_loops(), loop_kv_name(m.kv_mode()));
  fprintf(stderr, "prompt %d tok in %.3f ms; decode %zu tok in %.3f ms (%.6f tok/s); GPU %.3f ms\n", n, prefill_ms, out.size() - 1, decode_ms, 1000 * (out.size() - 1) / decode_ms, gpu_ms);
}
