import datetime,fcntl,hashlib,json,os,pathlib,re,signal,socket,subprocess,sys,time,urllib.request
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');E=R/'controlled-ready-20261108';E.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'bf16/bench/harness'));import gpu_hogs
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'preflight'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def environment(name):
 env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};p=E/'homes'/name;p.mkdir(parents=True,exist_ok=True)
 env.update(PATH='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',KAPITSA_NO_AUTO_UPDATE='1',KAPITSA_HOME=str(p));return env
def run(name,cmd,cwd=None,gpu=True,timeout=3600):
 row={'name':name,'command':list(map(str,cmd)),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:row['skipped']='GPU busy';save();return False
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=cwd or R/'reference',env=environment(name),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row['timeout']=timeout;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 return row.get('rc')==0
def http(arm,model,tag,flags):
 name=tag+'-'+arm
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 cmd=[str(R/arm/'build/kapitsa'),'serve','--model',str(model),'--private','--host','127.0.0.1','--port',str(port),'--ctx','32768','--slots','2','--disk-cache','0',*flags]
 row={'name':name+'-server','command':cmd};S['runs'].append(row);save()
 with (E/(name+'-server.log')).open('x') as f:
  p=subprocess.Popen(cmd,cwd=R/arm,env=environment(name+'-server'),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:
   row['ready']=False
   for _ in range(300):
    if p.poll()!=None:break
    try:
     with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as res:
      if res.status==200:row['ready']=True;break
    except Exception:pass
    time.sleep(2)
   save()
   if row['ready']:run(name,['python3',R/arm/'tests/test_server.py',f'http://127.0.0.1:{port}'],timeout=1800)
  finally:
   if p.poll()==None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=30)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   row['cleaned_up']=True;row['rc_after_stop']=p.returncode;save()
try:
 prior=R/'ready-push-20261108/state.json'
 while not json.loads(prior.read_text())['status'].startswith(('complete','failed')):S['status']='waiting prior numeric job';save();time.sleep(10)
 S['heads']={x:subprocess.check_output(['git','rev-parse','HEAD'],cwd=R/x,text=True).strip() for x in ['reference','bf16','dory']}
 assert S['heads']==json.loads(prior.read_text())['heads'];S['binary_sha256']={f'{a}/{b}':sha(R/a/'build'/b) for a in S['heads'] for b in ['kapitsa','ni_run']};save()
 models={'4b':pathlib.Path('/Users/bytedance/pr934-m3-validation-20261105/modelhome/models/qwen3.5-4b-4bit'),'35b':pathlib.Path('/Users/bytedance/models/Qwen3.6-35B-A3B-4bit')}
 text='<|im_start|>user\nWrite a detailed numbered list explaining the integers from 1 through 100, one sentence per integer. Begin with 1 and continue without stopping early.\n<|im_end|>\n<|im_start|>assistant\n';(E/'prompt.txt').write_text(text)
 for m,p in models.items():
  ids=subprocess.check_output([R/'model-checks/build/token_helper',p/'tokenizer.json','encode',E/'prompt.txt'],text=True);(E/(m+'.ids')).write_text(ids);S.setdefault('inputs',{})[m]={'ids_sha256':sha(E/(m+'.ids')),'tokenizer_sha256':sha(p/'tokenizer.json')}
 save()
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU';save();fcntl.flock(lock,fcntl.LOCK_EX)
  for mode,m,flags in [('4b-plain','4b',['--dflash','none','--spec','0']),('4b-kflash','4b',['--dflash','auto']),('35b-plain','35b',['--dflash','none','--spec','0'])]:
   for i,a in enumerate(['reference','bf16','reference','bf16']):run(f'{mode}-{i}-{a}',[R/a/'build/ni_run',models[m],'@'+str(E/(m+'.ids')),'256','0',*flags])
  for a in ['reference','bf16']:http(a,models['4b'],'4b-no-draft-http',['--dflash','none','--spec','0'])
  http('bf16',models['35b'],'35b-default-http',[])
 S['status']='complete; inspect IDs, actual HTTP timing conditions and all rc';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
