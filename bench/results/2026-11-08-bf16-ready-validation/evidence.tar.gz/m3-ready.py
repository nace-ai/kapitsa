import datetime,fcntl,hashlib,json,os,pathlib,re,shutil,signal,subprocess,sys,time
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');E=R/'ready-push-20261108';E.mkdir(exist_ok=False)
T={x:R/x for x in ['reference','bf16','dory']};heads={'reference':'bbd84e0d53be75866087aa615bdeb6f2411f393f','bf16':'5e174cb89eb991a705752d033f7f9da8edfeff87','dory':'b3bece8931c78885e682bfb8da771598d721093a'}
models={'35b':pathlib.Path('/Users/bytedance/models/Qwen3.6-35B-A3B-4bit'),'4b':pathlib.Path('/Users/bytedance/pr934-m3-validation-20261105/modelhome/models/qwen3.5-4b-4bit')}
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'heads':heads,'runs':[],'status':'building','models':{k:str(v) for k,v in models.items()}}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};env.update(PATH='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',PYTHONUNBUFFERED='1',KAPITSA_NO_AUTO_UPDATE='1')
def run(name,cmd,cwd,extra=None,required=True,timeout=3600,gpu=False):
 row={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'extra_env':extra or {},'start':datetime.datetime.now(datetime.timezone.utc).isoformat()};S['runs'].append(row);S['status']=name;save()
 penv=dict(env,**(extra or {}));home=E/'homes'/name;home.mkdir(parents=True);penv['KAPITSA_HOME']=str(home)
 mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:row['skipped']='GPU not quiet';save();return False
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=cwd,env=penv,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row['timeout']=timeout;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 if required:assert row.get('rc')==0,row
 return row.get('rc')==0
try:
 for name,p in T.items():
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()==heads[name]
  run(name+'-configure',['cmake','-S','.','-B','build','-DCMAKE_BUILD_TYPE=Release','-DKAPITSA_GIT='+heads[name][:8]],p)
  run(name+'-tools',['cmake','--build','build','-j','6','--target','kapitsa','logit_dump','ni_run','parser_test','structured_check'],p)
 S['binary_sha256']={f'{k}/{name}':sha(p/'build'/name) for k,p in T.items() for name in ['kapitsa','logit_dump','ni_run']};S['model_metadata']={k:{f:sha(p/f) for f in ['config.json','tokenizer.json']} for k,p in models.items()};save()
 for m,p in models.items():
  for arm in ['bf16','dory']:
   run(m+'-parser-'+arm,[T[arm]/'build/parser_test',p],T[arm],required=False)
   run(m+'-structured-'+arm,['python3','tests/test_structured.py','--cli','build',p],T[arm],required=False)
 sys.path.insert(0,str(T['bf16']/'bench/harness'));import gpu_hogs
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting for GPU';save();fcntl.flock(lock,fcntl.LOCK_EX);env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1')
  for mode,m,extra in [('35b','35b',{}),('4b-ane','4b',{'NI_ANE':'1','NI_ANE_UNITS':'1'})]:
   output={};valid=True
   for arm in ['reference','bf16','dory']:
    dest=E/(mode+'-'+arm+'-logits');output[arm]=dest
    cmd=[T[arm]/'build/logit_dump',models[m],dest,'--corpus',T[arm]/'bench/corpus.txt']
    if arm!='reference':cmd+=['--from',output['reference']]
    ok=run(mode+'-logits-'+arm,cmd,T[arm],extra,required=False,gpu=True);valid &=ok
    if arm!='reference' and ok:
     run(mode+'-compare-'+arm,['python3',T[arm]/'tools/logit_compare.py',output['reference'],dest,'--json',E/(mode+'-compare-'+arm+'.json')],T[arm],required=False)
   for arm,dest in output.items():
    for p in dest.rglob('*.f32'):
     S.setdefault('raw_hashes',{})[str(p.relative_to(E))]=sha(p);p.unlink()
   save()
 S['status']='complete; inspect numeric reports and ANE eval counts';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
