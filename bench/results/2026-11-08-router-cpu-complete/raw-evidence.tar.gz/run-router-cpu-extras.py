# Privacy-filtered derived export. Private environment identifiers and host resource records are omitted; measurements, outcomes and tested source/binary identities are retained. Modified commands are placeholder reproduction examples, not verbatim execution logs. Original bytes remain privately archived.
import datetime,json,os,pathlib,subprocess
root=pathlib.Path('$PRIVATE_PATH');c=root/'router';e=root/'router-cpu-extras';e.mkdir(exist_ok=False)
s={'pid':os.getpid(),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'status':'running'}
def save():(e/'state.json').write_text(json.dumps(s,indent=2)+'\n')
env=os.environ.copy();env.update(PATH='$PRIVATE_PATH',PYTHONUNBUFFERED='1')
for name,args in [('drex-max',['tests/test_drex_max.py','--cli','build']),('profile-gates',['tests/test_profile_gates.py']),('comment-gates',['tests/test_comment_gates.py']),('logit-dump-cli',['tests/test_logit_dump.py','build']),('qwen4-exp-pack',['tools/qwen4_exp_pack_test.py']),('packaging-patches',['tests/test_splash_patches.py','--apply'])]:
 row={'name':name,'command':['python3',*args]};s['runs'].append(row);save()
 with (e/(name+'.log')).open('x') as f:
  p=subprocess.Popen(row['command'],cwd=c,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();row['rc']=p.wait();save()
s['status']='complete';s['failures']=[x['name'] for x in s['runs'] if x['rc']];save()
