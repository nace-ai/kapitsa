import datetime,fcntl,hashlib,json,os,pathlib,subprocess,sys
r=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');c=r/'router';e=r/'router-balanced-180045';e.mkdir(exist_ok=False);src=r/'topk512_balanced_180045.cpp';exe=r/'topk512-balanced-180045'
s={'pid':os.getpid(),'production_source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip(),'checker_base':'dec964487d11821c8f4b5737b20ad64b974d0ac0','checker_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'change':'Measurement-only: alternating AB and BA pairs, three fresh processes; same production library/output addresses. No production modification.','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
def save():(e/'state.json').write_text(json.dumps(s,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_'))};env['PATH']='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def run(name,cmd):
 row={'name':name,'command':cmd};s['runs'].append(row);s['status']=name;save()
 with (e/(name+'.log')).open('x') as f:
  p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();row['rc']=p.wait();save()
 assert row['rc']==0,row
cmd=['/usr/bin/c++','-O3','-std=gnu++20','-arch','arm64','-isysroot','/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','-mmacosx-version-min=14.0',*[f'-I{c/d}' for d in ['src','include','third_party']],str(src),str(c/'build/libnaceinfer.a'),'-o',str(exe)]
for fw in ['Metal','Foundation','CoreFoundation','IOSurface','IOKit','ImageIO','CoreGraphics','Security','SystemConfiguration','Accelerate']:cmd+=['-framework',fw]
try:
 run('build',cmd);s['binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest();save()
 sys.path.insert(0,str(c/'bench/harness'));import gpu_hogs
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  s['status']='waiting for GPU lock';save();fcntl.flock(lock,fcntl.LOCK_EX);env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1')
  for i in range(3):
   s['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save();assert s['quiet'][0],'GPU not quiet'
   mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
   try:run(f'bench-{i+1}',[str(exe),'--bench'])
   finally:mon.stop();s.setdefault('contention',{})[str(i+1)]=gpu_hogs.summarize_samples(mon.samples);save()
 s['status']='complete';save()
except BaseException as ex:s['status']='failed';s['error']=repr(ex);save();raise
