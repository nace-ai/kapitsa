# Privacy-filtered derived export. Private environment identifiers and host resource records are omitted; measurements, outcomes and tested source/binary identities are retained. Modified commands are placeholder reproduction examples, not verbatim execution logs. Original bytes remain privately archived.
import datetime,fcntl,hashlib,json,os,pathlib,signal,subprocess,sys,time
R=pathlib.Path('$PRIVATE_PATH');E=R/'router-ready-20261108';E.mkdir(exist_ok=False);T={'reference':R/'router-reference','router':R/'router'};H={'reference':'f22effb9bdda7fa17be5e4ce614383a35e1cc62a','router':'dc82cf0f39b942157e86b0cd5e518e5caed17e61'}
S={'pid':os.getpid(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'heads':H,'status':'waiting prior controlled job'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def env(name):
 e={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_','BENCH_'))};p=E/'homes'/name;p.mkdir(parents=True,exist_ok=True);e.update(PATH='$PRIVATE_PATH',KAPITSA_HOME=str(p),KAPITSA_NO_AUTO_UPDATE='1',NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1');return e
def run(name,cmd,tree,gpu=False,required=True):
 row={'name':name,'command':list(map(str,cmd)),'cwd':str(tree),'start':time.time()};S['runs'].append(row);S['status']=name;save();mon=None
 if gpu:
  row['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=120,exclude_roots=[os.getpid()]);save()
  if not row['quiet'][0]:raise RuntimeError('GPU not quiet')
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
 try:
  with (E/(name+'.log')).open('x') as f:
   p=subprocess.Popen(row['command'],cwd=tree,env=env(name),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
   try:row['rc']=p.wait(timeout=3600)
   except subprocess.TimeoutExpired:
    row['timeout']=3600;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    row['rc']=p.returncode
 finally:
  if mon:mon.stop();row['contention']=gpu_hogs.summarize_samples(mon.samples)
  row['end']=time.time();save()
 if required:assert row.get('rc')==0,row
 return row.get('rc')==0
save()
try:
 while not json.loads((R/'controlled-ready-20261108/state.json').read_text())['status'].startswith(('complete','failed')):time.sleep(10)
 assert not T['reference'].exists();run('create-reference',['git','worktree','add','--detach',T['reference'],H['reference']],T['router'])
 for a,t in T.items():
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=t,text=True).strip()==H[a]
  run(a+'-configure',['cmake','-S','.','-B','build','-DCMAKE_BUILD_TYPE=Release','-DKAPITSA_GIT='+H[a][:8]],t)
  run(a+'-build',['cmake','--build','build','-j','6','--target','kapitsa','logit_dump','ni_run','parser_test','structured_check'],t)
 S['binary_sha256']={a+'/'+b:sha(t/'build'/b) for a,t in T.items() for b in ['kapitsa','logit_dump','ni_run']};save()
 models={'4b':pathlib.Path('$PRIVATE_PATH'),'35b':pathlib.Path('$PRIVATE_PATH')}
 for m,p in models.items():
  run(m+'-parser',[T['router']/'build/parser_test',p],T['router'],required=False);run(m+'-structured',['python3','tests/test_structured.py','--cli','build',p],T['router'],required=False)
 sys.path.insert(0,str(T['router']/'bench/harness'));import gpu_hogs
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU for controls';save();fcntl.flock(lock,fcntl.LOCK_EX)
  for m,p in models.items():
   outputs=[]
   for a,t in T.items():
    d=E/(m+'-'+a+'-logits');outputs.append(d);cmd=[t/'build/logit_dump',p,d,'--corpus',t/'bench/corpus.txt']
    if a=='router':cmd+=['--from',outputs[0]]
    run(m+'-logits-'+a,cmd,t,gpu=True)
   run(m+'-compare',['python3',T['router']/'tools/logit_compare.py',*outputs,'--json',E/(m+'-compare.json')],T['router'],required=False)
   for d in outputs:
    for f in d.rglob('*.f32'):S.setdefault('raw_sha256',{})[str(f.relative_to(E))]=sha(f);f.unlink()
   save()
 S['status']='controls complete; waiting complete model table';save()
 while True:
  state=R/'flash-complete-ready/parallel-state.json';table=json.loads(state.read_text())
  if table['status']=='failed':raise RuntimeError('table download failed: '+str(table.get('error')))
  if table['status'].startswith('complete;'):break
  time.sleep(15)
 p=pathlib.Path(table['model']);S['model']=str(p);S['table_sha256']=table['sha256'];save()
 for what,cmd in [('parser',[T['router']/'build/parser_test',p]),('structured',['python3','tests/test_structured.py','--cli','build',p])]:run('flash-'+what,cmd,T['router'],required=False)
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting GPU for Flash-Next';save();fcntl.flock(lock,fcntl.LOCK_EX)
  outputs=[]
  for a,t in T.items():
   d=E/('flash-'+a+'-logits');outputs.append(d);cmd=[t/'build/logit_dump',p,d,'--corpus',t/'bench/corpus.txt']
   if a=='router':cmd+=['--from',outputs[0]]
   run('flash-logits-'+a,cmd,t,gpu=True)
  run('flash-compare',['python3',T['router']/'tools/logit_compare.py',*outputs,'--json',E/'flash-compare.json'],T['router'],required=False)
  for d in outputs:
   for f in d.rglob('*.f32'):S.setdefault('raw_sha256',{})[str(f.relative_to(E))]=sha(f);f.unlink()
  save()
 S['status']='complete; inspect all outputs; model performance and HTTP follow-up next';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
