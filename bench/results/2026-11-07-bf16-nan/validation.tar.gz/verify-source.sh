#!/usr/bin/env bash
set -euo pipefail
export PATH=/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH
root=/Users/bytedance/kapitsa-two-candidates-20261107
kind=$1
head=$2
cd "$root/$kind"
mkdir -p "$root/$kind-evidence/extra"
export VK_RUN=two-candidates-$kind VK_EVIDENCE="$root/$kind-evidence/vk"
trap 'echo $? > "$root/$kind.rc"' EXIT
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release > "$root/$kind-evidence/configure.log" 2>&1
V=.dsh/skills/verify-kapitsa/scripts/vk
$V build kapitsa api_test execution_session_test http_stream_test bench_test update_test prefix_cache_test grammar_test structured_check fn_store_test fn_dflash_test drafter_attach_test tokenizer_test iq_layout_test exl3_test remote_test cluster_test split_place_test gemm_slices_test device_profile_test qwen4_config_test json_file_test affine_pack_test systemone systemone_test systemone_codes_probe_test systemone_codes_driver splash_protocol_test splash_runtime_test splash_discover_test splash_plan_test ws_upgrade_test logit_dump
$V cpu-tests
for target in execution_session_test http_stream_test drafter_attach_test exl3_test device_profile_test qwen4_config_test json_file_test affine_pack_test systemone_test systemone_codes_probe_test splash_protocol_test splash_runtime_test splash_discover_test splash_plan_test; do
  build/$target > "$root/$kind-evidence/extra/$target.log" 2>&1
  echo "PASS extra $target"
done
for script in tests/test_profile_gates.py tests/test_comment_gates.py tests/test_drex_max.py tests/test_logit_dump.py tools/qwen4_exp_pack_test.py; do
  name=$(basename "$script" .py)
  case "$name" in
    test_drex_max) python3 "$script" --cli build > "$root/$kind-evidence/extra/$name.log" 2>&1 ;;
    test_logit_dump) python3 "$script" build > "$root/$kind-evidence/extra/$name.log" 2>&1 ;;
    *) python3 "$script" > "$root/$kind-evidence/extra/$name.log" 2>&1 ;;
  esac
  echo "PASS extra $name"
done
$V checks bbd84e0d53be75866087aa615bdeb6f2411f393f
$V doctor > "$root/$kind-evidence/doctor.log"
git rev-parse HEAD > "$root/$kind-evidence/source-head.txt"
test "$(git rev-parse HEAD)" = "$head"
if [[ "$kind" = dory ]]; then
  $V build dory_reduce_check
  $V gpu run --eta 5 --label 'Dory shared reduction source checks' -- bash "$root/dory-gpu.sh"
fi
$V cleanup
