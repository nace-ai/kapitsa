#!/usr/bin/env bash
set -euo pipefail
export PATH=/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH
R=/Users/bytedance/kapitsa-two-candidates-20261107
kind=$1
cd "$R"
while [[ ! -f "$kind.rc" ]]; do sleep 2; done
if [[ "$(cat "$kind.rc")" = 0 ]]; then touch "$kind.final.done"; exit 0; fi
# The original verifier must have reached its version-label check, after every CPU test.
grep -q '^0 failed$' "$kind.log"
test "$(grep -c '^PASS extra ' "$kind.log")" = 19
grep -q 'STALE: build/kapitsa' "$kind-evidence/doctor.log"
mv "$kind.rc" "$kind-initial-label.rc"
trap 'echo $? > "$R/$kind.rc"' EXIT
cd "$R/$kind"
export VK_RUN=two-candidates-$kind VK_EVIDENCE="$R/$kind-evidence/vk"
V=.dsh/skills/verify-kapitsa/scripts/vk
head=$(git rev-parse HEAD)
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DKAPITSA_GIT="${head:0:8}" > "$R/$kind-evidence/configure-explicit-label.log" 2>&1
# Only the executable version macros change; the engine library has no KAPITSA_GIT definition.
cmake --build build -j --target kapitsa logit_dump > "$R/$kind-evidence/build-explicit-label.log" 2>&1
python3 tests/test_update.py build > "$R/$kind-evidence/update-explicit-label.log" 2>&1
$V doctor > "$R/$kind-evidence/doctor-explicit-label.log"
git rev-parse HEAD > "$R/$kind-evidence/source-head.txt"
if [[ "$kind" = dory ]]; then
  $V build dory_reduce_check
  $V gpu run --eta 5 --label 'Dory shared reduction source checks' -- bash "$R/dory-gpu.sh"
fi
$V cleanup
touch "$R/$kind.final.done"
