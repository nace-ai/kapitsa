import pathlib,json,os,sys,subprocess,hashlib,fcntl,datetime
E=pathlib.Path(__file__).parent/'m4';exe=E/'topk512_check';S={'pid':os.getpid(),'source':'dc82cf0f39b942157e86b0cd5e518e5caed17e61','binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'mac':'Apple M4 Pro,48GiB,macOS15.7.1(24G231)','build':'same arm64 Release binary from M3 Ultra, hash verified'}
assert S['binary_sha256']=='7635c5575ef21c7c796f615c9529155d32d06626e25c2690cb3623f9cca186e7'
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
sys.path.insert(0,'/Users/bytedance/.codex/worktrees/router-first-maximum/qwen-nameless-tool/bench/harness');import gpu_hogs
env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1')
def run(name,args,extra={}):
 S['status']=name;r={'name':name,'command':[str(exe),*args],'extra_env':extra};S['runs'].append(r);save()
 with (E/(name+'.log')).open('x') as f:r['rc']=subprocess.call(r['command'],env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 save()
 if r['rc']:raise RuntimeError((name,r['rc']))
try:
 with open('/tmp/kapitsa-gpu.lock','a') as f:
  S['status']='waiting for GPU';save();fcntl.flock(f,fcntl.LOCK_EX)
  run('gpu-small',['--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1'})
  run('gpu-small-safe',['--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1','NI_MATH_SAFE':'1'})
  run('gpu-normal',['--gpu'])
  S['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save()
  if not S['quiet'][0]:raise RuntimeError('GPU not quiet')
  m=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);m.start()
  try:run('gpu-bench',['--bench'])
  finally:m.stop();S['contention']=gpu_hogs.summarize_samples(m.samples);S['samples']=m.samples;save()
 S['status']='complete';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
