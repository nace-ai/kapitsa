# Privacy-filtered derived export. Private environment identifiers and host resource records are omitted; measurements, outcomes and tested source/binary identities are retained. Modified commands are placeholder reproduction examples, not verbatim execution logs. Original bytes remain privately archived.
import datetime,fcntl,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('$PRIVATE_PATH')
checkout=root/'router'
evidence=root/'router-reporting';evidence.mkdir(exist_ok=False)
source=root/'topk512_reporting.cpp'
exe=root/'topk512-reporting'
state={'production_source':subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip(),'checker_base':'13fe5470a11fe46d31166ed34fae218bb0da2677','checker_change':'The B static-memory diagnostic now reads moe_topk512_rows; no calculation or timing change.','checker_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
def save(): (evidence/'state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd,env=None):
 row={'name':name,'command':cmd};state['runs'].append(row);save()
 with (evidence/(name+'.log')).open('x') as f:row['rc']=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 save();assert row['rc']==0,row
cmd=['/usr/bin/c++','-O3','-std=gnu++20','-arch','arm64','-isysroot','/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk','-mmacosx-version-min=14.0',*[f'-I{checkout/d}' for d in ['src','include','third_party']],str(source),str(checkout/'build/libnaceinfer.a'),'-o',str(exe)]
for fw in ['Metal','Foundation','CoreFoundation','IOSurface','IOKit','ImageIO','CoreGraphics','Security','SystemConfiguration','Accelerate']:cmd+=['-framework',fw]
run('build',cmd)
state['binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest();save()
env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1',MTL_SHADER_VALIDATION='1',MTL_DEBUG_LAYER='1')
with open('/tmp/kapitsa-gpu.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 state['env']={k:env[k] for k in ['NI_LOCK_HELD','NACE_GPU_LOCK_HELD','MTL_SHADER_VALIDATION','MTL_DEBUG_LAYER']};save()
 run('gpu-small',[str(exe),'--gpu','--small'],env)
state['status']='complete';save()
