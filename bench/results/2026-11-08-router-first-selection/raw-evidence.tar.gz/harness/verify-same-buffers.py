import pathlib,json,os,sys,subprocess,hashlib,fcntl,datetime
E=pathlib.Path(sys.argv[1]);exe=pathlib.Path(sys.argv[2]);E.mkdir(exist_ok=False)
sys.path.insert(0,sys.argv[3]);import gpu_hogs
S={'pid':os.getpid(),'production_source':'dc82cf0f39b942157e86b0cd5e518e5caed17e61','checker_source':'13fe5470a11fe46d31166ed34fae218bb0da2677','binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[],'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'macos':subprocess.check_output(['sw_vers'],text=True),'comparison':'Both pipelines from the same production library, Metal3.1; original kernel unchanged from f22effb9. Timing arms also share output addresses. Earlier extra-library Metal3.2 timing comparisons are confounded.'}
def save():(E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('NI_','NACE_','KAPITSA_','MTL_'))};env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1')
def run(name,args,extra={}):
 S['status']=name;r={'name':name,'command':[str(exe),*args],'extra_env':extra};S['runs'].append(r);save()
 with (E/(name+'.log')).open('x') as f:r['rc']=subprocess.call(r['command'],env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 save()
 if r['rc']:raise RuntimeError((name,r['rc']))
try:
 with open('/tmp/kapitsa-gpu.lock','a') as f:
  S['status']='waiting for GPU';save();fcntl.flock(f,fcntl.LOCK_EX)
  run('gpu-small',['--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1'})
  run('gpu-small-safe',['--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1','NI_MATH_SAFE':'1'})
  run('gpu-normal',['--gpu'])
  S['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save()
  if not S['quiet'][0]:raise RuntimeError('GPU not quiet')
  m=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);m.start()
  try:run('gpu-bench',['--bench'])
  finally:m.stop();S['contention']=gpu_hogs.summarize_samples(m.samples);S['samples']=m.samples;save()
 S['status']='complete';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
