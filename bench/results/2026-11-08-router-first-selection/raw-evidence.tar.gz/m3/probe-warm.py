import pathlib,json,fcntl,subprocess,sys,os,hashlib,time
r=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107');e=r/'router-warm';e.mkdir(exist_ok=False)
s={'pid':os.getpid(),'source':subprocess.check_output(['git','-C',str(r/'router'),'rev-parse','HEAD'],text=True).strip(),'kind':'diagnostic checker linked to current full-source library; extended rows and48x8192paired warmup; numeric kernels unchanged','command':[str(r/'topk512_warm'),'--bench']}
def save(): (e/'state.json').write_text(json.dumps(s,indent=2)+'\n')
save();sys.path.insert(0,str(r/'router/bench/harness'));import gpu_hogs
with open('/tmp/kapitsa-gpu.lock','a') as f:
 s['status']='waiting for GPU';save();fcntl.flock(f,fcntl.LOCK_EX)
 s['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save()
 if not s['quiet'][0]:s['status']='GPU not quiet';save();raise SystemExit(1)
 s['status']='timing';save();m=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);m.start()
 with (e/'bench.log').open('x') as out:s['rc']=subprocess.call(s['command'],env={**os.environ,'NI_LOCK_HELD':'1','NACE_GPU_LOCK_HELD':'1'},stdout=out,stderr=subprocess.STDOUT)
 m.stop();s['contention']=gpu_hogs.summarize_samples(m.samples);s['samples']=m.samples;s['status']='complete';save()
