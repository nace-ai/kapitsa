import datetime,fcntl,json,os,pathlib,subprocess,sys
R=pathlib.Path('/Users/bytedance/kapitsa-two-candidates-20261107'); C=R/'router'; E=R/'router-final-evidence';E.mkdir(exist_ok=True)
import time
while True:
 prior=json.loads((R/'router-v2-evidence/state.json').read_text())
 if prior['status'] in ['completed','failed']: break
 time.sleep(5)
subprocess.run(['git','-C',str(C),'fetch',str(R/'router-source-final.bundle'),'HEAD'],check=True)
subprocess.run(['git','-C',str(C),'merge','--ff-only','FETCH_HEAD'],check=True)
S={'pid':os.getpid(),'source':subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
def save(): (E/'state.json').write_text(json.dumps(S,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/Users/bytedance/kapitsa-968-evidence-20261106/venv/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['PYTHONUNBUFFERED']='1';env['VK_RUN']='router-first-maximum';env['VK_EVIDENCE']=str(E/'vk')
def run(name,cmd,extra={}):
 S['status']=name;row={'name':name,'command':cmd};S['runs'].append(row);save()
 with (E/(name+'.log')).open('x') as f:
  p=subprocess.Popen(cmd,cwd=C,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();row['rc']=p.wait();save()
 if row['rc']:raise RuntimeError((name,row['rc']))
try:
 v='.dsh/skills/verify-kapitsa/scripts/vk'
 run('configure',['cmake','-S','.','-B','build','-DCMAKE_BUILD_TYPE=Release','-DKAPITSA_GIT='+S['source'][:8]])
 run('build',[v,'build','kapitsa','topk512_check','fn_check','api_test','execution_session_test','http_stream_test','bench_test','update_test','prefix_cache_test','grammar_test','structured_check','fn_store_test','fn_dflash_test','drafter_attach_test','tokenizer_test','iq_layout_test','exl3_test','remote_test','cluster_test','split_place_test','gemm_slices_test','device_profile_test','qwen4_config_test','json_file_test','affine_pack_test','systemone','systemone_test','systemone_codes_probe_test','systemone_codes_driver','splash_protocol_test','splash_runtime_test','splash_discover_test','splash_plan_test','ws_upgrade_test','logit_dump'])
 run('doctor',[v,'doctor'])
 sys.path.insert(0,str(C/'bench/harness'));import gpu_hogs
 with open('/tmp/kapitsa-gpu.lock','a') as lock:
  S['status']='waiting for GPU lock';save();fcntl.flock(lock,fcntl.LOCK_EX)
  env.update(NI_LOCK_HELD='1',NACE_GPU_LOCK_HELD='1')
  run('gpu-small',['build/topk512_check','--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1'})
  run('gpu-small-safe',['build/topk512_check','--gpu','--small'],{'MTL_SHADER_VALIDATION':'1','MTL_DEBUG_LAYER':'1','NI_MATH_SAFE':'1'})
  run('gpu-normal',['build/topk512_check','--gpu'])
  S['quiet']=gpu_hogs.wait_quiet(maxpct=.1,quiet_s=15,timeout_s=60,exclude_roots=[os.getpid()]);save()
  if not S['quiet'][0]:raise RuntimeError('GPU not quiet for timings')
  mon=gpu_hogs.ContentionMonitor([os.getpid()],interval=.5);mon.start()
  try:run('gpu-bench',['build/topk512_check','--bench'])
  finally:mon.stop();S['contention']=gpu_hogs.summarize_samples(mon.samples);S['samples']=mon.samples;save()
 env.pop('NI_LOCK_HELD');env.pop('NACE_GPU_LOCK_HELD')
 run('cpu-tests',[v,'cpu-tests'])
 for target in ['execution_session_test','http_stream_test','drafter_attach_test','exl3_test','device_profile_test','qwen4_config_test','json_file_test','affine_pack_test','systemone_test','systemone_codes_probe_test','splash_protocol_test','splash_runtime_test','splash_discover_test','splash_plan_test']:
  run(target,['build/'+target])
 run('checks',[v,'checks','f22effb9bdda7fa17be5e4ce614383a35e1cc62a'])
 run('cleanup',[v,'cleanup']);S['status']='completed';save()
except BaseException as e:S['status']='failed';S['error']=repr(e);save();raise
